// Suvera Crackers Google Sheets logger — configure before deployment.
// Create a Google Sheet, paste its ID below, then deploy as a Web App.
// For production, prefer authenticated server-side calls; don't rely on public client calls.
const SHEET_ID = "PASTE_GOOGLE_SHEET_ID_HERE";
const ADMIN_SECRET = "REPLACE_WITH_A_LONG_RANDOM_SECRET";
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    if (body.secret !== ADMIN_SECRET) return output({ok:false,error:"unauthorized"});
    if (body.type !== "order" || !body.order) return output({ok:false,error:"invalid request"});
    const ss = SpreadsheetApp.openById(SHEET_ID);
    const sh = ss.getSheetByName("Orders") || ss.insertSheet("Orders");
    if (sh.getLastRow() === 0) sh.appendRow(["Order No","Created","Status","Name","Phone","Email","Address","Items JSON","Subtotal","Packing","Total","Notes"]);
    const o = body.order;
    sh.appendRow([o.orderNo,o.created,o.status,o.name,o.phone,o.email,o.address,JSON.stringify(o.items),o.subtotal,o.packing,o.total,o.notes]);
    return output({ok:true});
  } catch (err) { return output({ok:false,error:String(err)}); }
}
function output(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}